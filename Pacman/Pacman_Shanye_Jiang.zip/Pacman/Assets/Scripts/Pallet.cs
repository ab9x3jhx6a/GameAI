﻿using UnityEngine;
using System.Collections;

public class Pallet : MonoBehaviour {

	public Transform Pacman;
	// Update is called once per frame
	void Update () {
		
	}
}
